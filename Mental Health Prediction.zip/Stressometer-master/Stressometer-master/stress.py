from flask import Flask, render_template, url_for, flash, redirect, request, session
from time import timezone
from forms import RegistrationForm, LoginForm
from flask_sqlalchemy import SQLAlchemy
import os
from sqlalchemy.sql import func
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import pickle 
import numpy as np
from joblib import load

####################################### DATABASE ######################################
# Load the model using joblib
try:
    model = load(r'C:\Users\DELL\Downloads\Stressometer-master\Stressometer-master\models.pkl')
    print(f"Model loaded successfully: {type(model)}")
except Exception as e:
    print(f"Error loading model: {e}")
    model = None

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'users.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable tracking so app uses less memory

db = SQLAlchemy(app)

class Users(db.Model, UserMixin):
    id = db.Column(db.Integer(), primary_key=True)
    username = db.Column(db.String(length=50), unique=True, nullable=False)
    email = db.Column(db.String(length=100), unique=True, nullable=False)
    password = db.Column(db.String(length=100), nullable=False)
    user_type = db.Column(db.String(length=20), nullable=False)
    stress_level = db.Column(db.String(length=100), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), server_default=func.now())

    def __repr__(self):
        return f'<Student {self.username}>'

################################ DATABASE END ##########################################

app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html', title="Home")

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', title="Dashboard")

@app.route('/view/<type>')
@login_required
def view(type="student"):
    if type == "student":
        users = Users.query.filter_by(user_type='student').all()
    else:
        users = Users.query.filter_by(user_type='admin').all()

    return render_template('view.html', title="Students Details", users=users)

@app.route('/add_admin', methods=['GET', 'POST'])
@login_required
def add_admin():
    form = RegistrationForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            user_type = "admin"
            stressLevel = "Not measured"
            
            new_user = Users.query.filter_by(username=username).first()
            new_email = Users.query.filter_by(email=email).first()
   
            if new_user:
                flash('The username is already taken.', 'danger')
            elif new_email:
                flash('The Email is already registered.', 'danger')
            else:
                user = Users(username=username, email=email, password=password, user_type=user_type, stress_level=stressLevel)             
                db.session.add(user)
                db.session.commit()
                reg_user = Users.query.filter_by(username=username).first()
                flash(f'Admin account created for {reg_user.username}!', 'success')

    return render_template('addAdmin.html', title="Add new admin", form=form)

@app.route("/register", methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            user_type = "student"
            stressLevel = "Not measured"

            new_user = Users.query.filter_by(username=username).first()
            new_email = Users.query.filter_by(email=email).first()

            if new_user:
                flash('The username is already taken.', 'danger')
            elif new_email:
                flash('The Email is already registered.', 'danger')
            else:
                user = Users(username=username, email=email, password=password, user_type=user_type, stress_level=stressLevel)             
                db.session.add(user)
                db.session.commit()
                reg_user = Users.query.filter_by(username=username).first()
                flash(f'Account created for {reg_user.username}!', 'success')
                return redirect(url_for('home'))
    return render_template('register.html', title='Register', form=form)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(int(user_id))

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            email = request.form['email']
            password = request.form['password']
            session['password'] = request.form['password']
            session['email'] = request.form['email']
            
            user_db = Users.query.filter_by(email=email).first()
            
            if user_db:
                password_db = user_db.password
                if password_db == password:
                    login_user(user_db)
                    flash("You have been logged in!", 'success')
                    return redirect(url_for('dashboard'))
                else:
                    flash('Login Unsuccessful. Please check email and password', 'danger')
            else:
                flash('User does not exist!', 'danger')

    return render_template('login.html', title='Login', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("You have been logged out!")
    return redirect(url_for('home'))

@app.route('/form')
def form():
    return render_template('form.html')

@app.route("/predict", methods=['POST'])
def predict():
    if model:
        try:
            m_f = int(request.form.get("gender"))

            financial_issues = 0
            size_financial = 4
            for i in range(size_financial):
                s = "financial_issues" + str(i)
                if request.form.get(s) is not None:
                    financial_issues += 1

            family_issues = 0
            size_family = 4
            for i in range(size_family):
                s = "family_issues" + str(i)
                if request.form.get(s) is not None:
                    family_issues += 1

            s_h = int(request.form.get("study_hours"))

            health_issues = 0
            size_health = 10
            for i in range(size_health):
                s = "health_issues" + str(i)
                if request.form.get(s) is not None:
                    health_issues += 1

            friends_issues = 0
            size_friends = 6
            for i in range(size_friends):
                s = "friends_issues" + str(i)
                if request.form.get(s) is not None:
                    friends_issues += 1

            t_f = int(request.form.get("time_with_friends"))
            overload = int(request.form.get("overload"))
            unpleasant = int(request.form.get("unpleasant"))
            academic = int(request.form.get("academic"))
            career = int(request.form.get("career"))
            criticism = int(request.form.get("criticism"))
            conflicts = int(request.form.get("conflicts"))

            final_features = [np.array([m_f, financial_issues, family_issues, s_h, health_issues, friends_issues,
                                        t_f, overload, unpleasant, academic, career, criticism, conflicts])]
            
            prediction = model.predict(final_features)
            print(prediction)
            output = prediction[0]
            if output == 0:
                pred = "Acute Stress"
            elif output == 1:
                pred = "Episodic Acute Stress"
            else:
                pred = "Chronic Stress"

            if current_user.is_authenticated:
                reg_user = Users.query.filter_by(email=session["email"]).first()
                username = reg_user.username
                num_rows_updated = Users.query.filter_by(username=username).update(dict(stress_level=pred))
                db.session.commit()
            return render_template('result.html', prediction_text=pred)
        except Exception as e:
            flash(f"Error in prediction: {e}", 'danger')
            return render_template('result.html')

    else:
        flash("Model not loaded correctly", 'danger')
        return redirect(url_for('home'))

@app.route("/result")
def result():
    return render_template('result.html')

if __name__ == "__main__":
    app.run(debug=True)
